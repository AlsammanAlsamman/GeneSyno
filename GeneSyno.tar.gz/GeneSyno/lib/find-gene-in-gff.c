#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef enum { false, true } bool;
int main(int argc, char *argv[])
{
    FILE *fp;
    size_t len=0;
    ssize_t read;
    char *line=NULL;
    fp=fopen(argv[2],"r");
    if(fp == NULL)
        exit(EXIT_FAILURE);
    while((read=getline(&line,&len,fp))!=-1) {
        if(strstr(line, "	gene	") != NULL) {
			 line[strlen(line)]='\0';
             char gene_form_1[50]="gene=";
             char gene_form_2[50]=",";
             char gene_form_3[50]="=";
             char gene_form_4[50]=",";
             //1
             strcat(gene_form_1,argv[1]);
             strcat(gene_form_1,";");
             gene_form_1[strlen(gene_form_1)]='\0';
             //2
             strcat(gene_form_2,argv[1]);
             strcat(gene_form_2,",");             
             gene_form_2[strlen(gene_form_2)]='\0';
             //3
             strcat(gene_form_3,argv[1]);
             strcat(gene_form_3,",");             
             gene_form_3[strlen(gene_form_3)]='\0';
             //4 this needs to the same length
             strcat(gene_form_4,argv[1]);             
             gene_form_4[strlen(gene_form_4)]='\0';
             
             
             
             //matching
             char * pch_1;
             char * pch_2;
             char * pch_3;
			 char * pch_4;
		     pch_1 = strstr(line,gene_form_1);
		     pch_2 = strstr(line,gene_form_2);
		     pch_3 = strstr(line,gene_form_3);			
		     pch_4 = strstr(line,gene_form_4);
		     //pch_5 = strstr(line,gene_form_5);
             bool f_4 =((pch_4!=NULL)&&((strlen(pch_4)-2)==strlen(argv[1])));
             //
             if(pch_1 != NULL||pch_2 != NULL||pch_3 != NULL||f_4) {
                printf("%s\t%s", argv[1],line);
                fclose(fp);
                if (line)
                     free(line);
               exit(EXIT_SUCCESS);
                return 0;
               }
        }
    }
}
