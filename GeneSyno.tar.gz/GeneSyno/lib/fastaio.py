#!/usr/bin/python3

def read_fasta(file):
    seq = {}
    header = ""
    sequence = ""
    with open(file) as fp:
        for line in fp:
            line = line.strip()
            if len(line) > 0:
                if line[0] == ">":
                    if len(sequence) != 0 and len(header) > 0:
                        seq[header] =""
                        seq[header] = sequence
                        sequence=""
                    header = line.split(" ")[0][1:]
                sequence += line + "\n"
    seq[header] = sequence
    return seq
