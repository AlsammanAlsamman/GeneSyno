 # Copyright 2020 Alsamman <smahmoud@ageri.sci.eg>
 # 
 # This program is free software; you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation; either version 2 of the License, or
 # (at your option) any later version.
 # 
 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 # 
 # You should have received a copy of the GNU General Public License
 # along with this program; if not, write to the Free Software
 # Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 # MA 02110-1301, USA.


#!/usr/bin/python3
from lib import fastaio

import re
import sys
import os
chrdict={}


def get_info(linetext):
	gene={}
	line=linetext.split("\t")
	gene["name_in"]=line[0]
	gene["chr"]=line[1]
	gene["chr_st"]=line[4]
	gene["chr_end"]=line[5]
	line=linetext.split(";")
	for i in line:
		if "description=" in i:
			gene["desc"]=i
			gene["desc"]=gene["desc"].replace("description=","")
		if "gene_synonym=" in i:
			gene["gene_syn"]=i
			gene["gene_syn"]=gene["gene_syn"].replace("gene_synonym=","")
		if "gene=" in i:
			gene["gene"]=i
			gene["gene"]=gene["gene"].replace("gene=","")
	return gene

def get_gene_acc(genes):
	gene_accs={}
	with open("data/GENES-ACCESSIONS.txt") as geneacc:
		for line in geneacc:
			line=line.split("\t")
			for gene in genes:
				if gene == line[0]:
					if gene in gene_accs:
						gene_accs[gene].append(line[1].strip())
					else:
						gene_accs[gene]=[]
						gene_accs[gene].append(line[1].strip())
	return gene_accs
		


try:
	len(sys.argv[1])
except:
	print("Usage: GeneSyno [List_of_Genes]")
	sys.exit()

#Genes chromsomes
with open("data/chrom-list.txt","r") as chrofp:
	for chro in chrofp:
		chrdict[chro.split()[0]]=chro.split()[1]



#Genes List
genes_info=[]
#Genes INPUT
with open(sys.argv[1]) as genelist:
	for gene in genelist:
		command="./lib/find-gene-in-gff "+gene.strip()+" data/GRCh38_genomic.gff"
		stream=os.popen(command)
		out=stream.read().strip()
		if len(out) is not 0:
			line=out.split("\t")
			try:
				line[1]=chrdict[line[1]]
				genes_info.append(get_info("\t".join(line)))
			except:
				pass

# get genes info
infofile=open("GENES-INFO.csv","w+")
infofile.write("GeneName\tOfficial_Name\tDescription\tChr\tStart\tEnd\tGene_Synonym\n")
genes_names=[]
for gene in genes_info:
	print(gene["name_in"]+"\t"+
		gene["gene"]+"\t"+
		gene["desc"]+"\t"+
		gene["chr"]+"\t"+
		gene["chr_st"]+"\t"+
		gene["chr_end"]+"\t"+
		gene["gene_syn"],file=infofile)
	genes_names.append(gene["gene"])

infofile.close()

#get genes seq

genes_accs=get_gene_acc(genes_names)

#read protein sequences file

seqeunces=fastaio.read_fasta("data/GRCh38_protein.faa")

seqfile=open("GeneSequences.fasta","w+")

for gene in genes_accs:
	for acc in genes_accs[gene]:
		seqeunces[acc]=seqeunces[acc].replace(">",">"+gene+"_")
		print(seqeunces[acc],file=seqfile,end="")
seqfile.close()
